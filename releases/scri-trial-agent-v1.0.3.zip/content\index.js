let p=[],d=!1,g=null;function h(){if(console.log("SCRI Trial Agent content script loaded"),document.querySelector(".search-container")){k();return}C()}function C(){let t=!1;const e=new MutationObserver((a,s)=>{if(t)return;document.querySelector(".search-container")&&(console.log("SCRI Agent: Found .search-container, injecting interface"),t=!0,s.disconnect(),k())});e.observe(document.body,{childList:!0,subtree:!0}),setTimeout(()=>{t||(console.warn("SCRI Agent: .search-container not found after 30s, giving up"),e.disconnect())},3e4)}function k(){const t=document.querySelector(".search-container");if(!t){console.warn("SCRI Agent: Could not find .search-container");return}for(g=document.createElement("div");t.firstChild;)g.appendChild(t.firstChild);S(t)}function S(t){t.innerHTML=`
    <div id="scri-agent-wrapper">
      <div class="scri-agent-tabs-container">
        <!-- Tab Navigation -->
        <div class="scri-agent-tab-nav">
          <button class="scri-agent-tab-btn active" data-tab="chat">
            <span class="scri-agent-tab-icon">💬</span>
            <span>AI Navigator</span>
          </button>
          <button class="scri-agent-tab-btn" data-tab="search">
            <span class="scri-agent-tab-icon">🔍</span>
            <span>Search Trials</span>
          </button>
        </div>

        <!-- Tab Content -->
        <div class="scri-agent-tab-content">
          <!-- Chat Tab -->
          <div id="scri-agent-chat-tab" class="scri-agent-tab-panel active">
            <div class="scri-agent-chat-container" id="scri-agent-chat-container">
              <!-- Welcome State (centered) -->
              <div class="scri-agent-welcome" id="scri-agent-welcome">
                <div class="scri-agent-welcome-icon">🔬</div>
                <h1 class="scri-agent-welcome-title">Find Your Clinical Trial</h1>
                <p class="scri-agent-welcome-subtitle">I'll help you discover SCRI trials that match your needs</p>
                
                <div class="scri-agent-welcome-input-area">
                  <textarea 
                    id="scri-agent-input" 
                    class="scri-agent-input" 
                    placeholder="Tell me about your cancer type and location..."
                    rows="1"
                  ></textarea>
                  <button id="scri-agent-send" class="scri-agent-send-btn" aria-label="Send message">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" style="width: 20px !important; height: 20px !important; min-width: 20px; min-height: 20px;">
                      <line x1="22" y1="2" x2="11" y2="13"></line>
                      <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                    </svg>
                  </button>
                </div>
                
                <div class="scri-agent-suggestions">
                  <button class="scri-agent-suggestion" data-query="I have breast cancer and live in Nashville, TN (37203)">
                    🎀 Breast cancer near Nashville
                  </button>
                  <button class="scri-agent-suggestion" data-query="I have lung cancer and live in Denver, CO (80202)">
                    🫁 Lung cancer near Denver
                  </button>
                  <button class="scri-agent-suggestion" data-query="What types of cancer do you have trials for?">
                    📋 See all cancer types
                  </button>
                </div>
              </div>
              
              <!-- Chat State (after first message) -->
              <div class="scri-agent-chat-active" id="scri-agent-chat-active" style="display: none;">
                <div id="scri-agent-messages" class="scri-agent-messages">
                  <!-- Messages will be inserted here -->
                </div>
                
                <div class="scri-agent-input-area-bottom">
                  <textarea 
                    id="scri-agent-input-active" 
                    class="scri-agent-input" 
                    placeholder="Ask a follow-up question..."
                    rows="1"
                  ></textarea>
                  <button id="scri-agent-send-active" class="scri-agent-send-btn" aria-label="Send message">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" style="width: 20px !important; height: 20px !important; min-width: 20px; min-height: 20px;">
                      <line x1="22" y1="2" x2="11" y2="13"></line>
                      <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- Search Tab (Original Content) -->
          <div id="scri-agent-search-tab" class="scri-agent-tab-panel">
            <div id="scri-agent-original-content"></div>
          </div>
        </div>
      </div>
    </div>
  `;const e=document.getElementById("scri-agent-original-content");if(e&&g)for(;g.firstChild;)e.appendChild(g.firstChild);A(),$()}async function $(){try{const t=await chrome.runtime.sendMessage({type:"GET_API_KEY",payload:{}});t!=null&&t.hasKey||f()}catch(t){console.error("Failed to check API key status:",t),f()}}function f(){const t=document.getElementById("scri-agent-welcome");if(!t)return;t.innerHTML=`
    <div class="scri-agent-welcome-icon">🔑</div>
    <h1 class="scri-agent-welcome-title">One-Time Setup</h1>
    <p class="scri-agent-welcome-subtitle">Enter your OpenAI API key to enable the AI Trial Navigator</p>
    
    <div class="scri-agent-api-key-form">
      <div class="scri-agent-api-key-input-wrapper">
        <input 
          type="password" 
          id="scri-agent-api-key-input" 
          class="scri-agent-api-key-input"
          placeholder="sk-proj-..."
          autocomplete="off"
        />
        <button id="scri-agent-toggle-key" class="scri-agent-toggle-key" type="button" aria-label="Show/hide key">
          👁️
        </button>
      </div>
      <button id="scri-agent-save-key" class="scri-agent-save-key-btn">
        Save & Start Chatting
      </button>
      <p id="scri-agent-key-error" class="scri-agent-key-error" style="display: none;"></p>
    </div>
    
    <p class="scri-agent-key-help">
      Don't have an API key? <a href="https://platform.openai.com/api-keys" target="_blank">Get one here</a> (requires OpenAI account)
    </p>
    <p class="scri-agent-key-privacy">
      🔒 Your key is stored locally in your browser and never sent anywhere except OpenAI.
    </p>
  `;const e=document.getElementById("scri-agent-api-key-input"),a=document.getElementById("scri-agent-save-key"),s=document.getElementById("scri-agent-toggle-key"),n=document.getElementById("scri-agent-key-error");s==null||s.addEventListener("click",()=>{e.type==="password"?(e.type="text",s.textContent="🙈"):(e.type="password",s.textContent="👁️")});const i=async()=>{const c=e.value.trim();if(!c){n&&(n.textContent="Please enter your API key",n.style.display="block");return}if(!c.startsWith("sk-")){n&&(n.textContent='Invalid API key format. Keys should start with "sk-"',n.style.display="block");return}a&&(a.textContent="Saving...",a.disabled=!0);try{await chrome.runtime.sendMessage({type:"SET_API_KEY",payload:{key:c}}),window.location.reload()}catch{n&&(n.textContent="Failed to save key. Please try again.",n.style.display="block"),a&&(a.textContent="Save & Start Chatting",a.disabled=!1)}};a==null||a.addEventListener("click",i),e==null||e.addEventListener("keydown",c=>{c.key==="Enter"&&(c.preventDefault(),i())}),e==null||e.focus()}function A(){document.querySelectorAll(".scri-agent-tab-btn").forEach(n=>{n.addEventListener("click",()=>{const i=n.getAttribute("data-tab");i&&L(i)})});const t=document.getElementById("scri-agent-send"),e=document.getElementById("scri-agent-input");t==null||t.addEventListener("click",()=>y()),e==null||e.addEventListener("keydown",n=>{n.key==="Enter"&&!n.shiftKey&&(n.preventDefault(),y())});const a=document.getElementById("scri-agent-send-active"),s=document.getElementById("scri-agent-input-active");a==null||a.addEventListener("click",()=>b()),s==null||s.addEventListener("keydown",n=>{n.key==="Enter"&&!n.shiftKey&&(n.preventDefault(),b())}),document.querySelectorAll(".scri-agent-suggestion").forEach(n=>{n.addEventListener("click",()=>{const i=n.getAttribute("data-query");if(i){const c=document.getElementById("scri-agent-input");c&&(c.value=i,y())}})}),[e,s].forEach(n=>{n==null||n.addEventListener("input",()=>{n.style.height="auto",n.style.height=Math.min(n.scrollHeight,150)+"px"})})}function L(t){if(document.querySelectorAll(".scri-agent-tab-btn").forEach(e=>{e.classList.toggle("active",e.getAttribute("data-tab")===t)}),document.querySelectorAll(".scri-agent-tab-panel").forEach(e=>{e.classList.toggle("active",e.id===`scri-agent-${t}-tab`)}),t==="chat"){document.getElementById("scri-agent-welcome");const e=document.getElementById("scri-agent-chat-active");if((e==null?void 0:e.style.display)!=="none"){const a=document.getElementById("scri-agent-input-active");a==null||a.focus()}else{const a=document.getElementById("scri-agent-input");a==null||a.focus()}}}function T(){const t=document.getElementById("scri-agent-welcome"),e=document.getElementById("scri-agent-chat-active");if(t&&e){t.style.display="none",e.style.display="flex";const a=document.getElementById("scri-agent-input-active");a==null||a.focus()}}async function y(){const t=document.getElementById("scri-agent-input"),e=t.value.trim();!e||d||(t.value="",T(),await E(e))}async function b(){const t=document.getElementById("scri-agent-input-active"),e=t.value.trim();!e||d||(t.value="",t.style.height="auto",await E(e))}async function E(t){const e={id:l(),role:"user",content:t,timestamp:new Date};o(e);const a={id:l(),role:"assistant",content:"",timestamp:new Date,isLoading:!0};o(a),d=!0,v("Searching trials...");try{const s=await chrome.runtime.sendMessage({type:"CHAT",payload:{message:t}});if(w(a.id),d=!1,v(""),s!=null&&s.error){o({id:l(),role:"assistant",content:`❌ ${s.error}`,timestamp:new Date});return}const n={id:l(),role:"assistant",content:(s==null?void 0:s.text)||"Sorry, I encountered an error. Please try again.",timestamp:new Date,trials:s==null?void 0:s.trials};o(n)}catch(s){w(a.id),d=!1,v(""),o({id:l(),role:"assistant",content:`❌ Error: ${s instanceof Error?s.message:"Failed to connect. Please check your API key in the extension settings."}`,timestamp:new Date})}}function v(t){const e=document.getElementById("scri-agent-status");e&&(e.textContent=t)}function o(t){p.push(t),I(),t.role==="user"||t.isLoading?M():B(t.id)}function w(t){p=p.filter(e=>e.id!==t),I()}function I(){const t=document.getElementById("scri-agent-messages");t&&(t.innerHTML=p.map(e=>{if(e.isLoading)return`
          <div class="scri-agent-message scri-agent-message-assistant" data-message-id="${e.id}">
            <div class="scri-agent-message-content">
              <div class="scri-agent-loading">
                <span></span><span></span><span></span>
              </div>
            </div>
          </div>
        `;const a=e.role==="user"?"scri-agent-message-user":"scri-agent-message-assistant";let s="";return e.trials&&e.trials.length>0&&(s=`
          <div class="scri-agent-trials">
            ${e.trials.slice(0,5).map(n=>{var m;const i=n.scriUrl||(n.id?`https://trials.scri.com/trialdetail/${n.id}`:"#");let c="";if(n.closestLocation)c=`
                  <div class="scri-agent-trial-location">
                    📍 ${r(n.closestLocation.city)}, ${r(n.closestLocation.state)}
                    ${n.closestLocation.distance?` (~${n.closestLocation.distance} mi)`:""}
                    ${n.locationCount>1?` • +${n.locationCount-1} more locations`:""}
                  </div>
                `;else if(n.closestCity){const u=n;c=`
                  <div class="scri-agent-trial-location">
                    📍 ${r(u.closestCity||"")}, ${r(u.closestState||"")}
                    ${u.distance?` (~${u.distance} mi)`:""}
                  </div>
                `}return`
              <div class="scri-agent-trial-card" data-scri-url="${i}">
                <div class="scri-agent-trial-header">
                  <strong>${r(n.name)}</strong>
                  <span class="scri-agent-trial-phase">${((m=n.phases)==null?void 0:m.join(", "))||""}</span>
                </div>
                <div class="scri-agent-trial-nct">${r(n.nctId)}</div>
                ${n.title?`<div class="scri-agent-trial-title">${r(n.title)}</div>`:""}
                ${c}
                <div class="scri-agent-trial-links">
                  <a href="${i}" target="_blank" class="scri-agent-trial-link scri-agent-trial-link-primary" onclick="event.stopPropagation()">
                    🏥 View on SCRI
                  </a>
                  ${n.nctId?`
                    <a href="https://clinicaltrials.gov/study/${n.nctId}" target="_blank" class="scri-agent-trial-link scri-agent-trial-link-secondary" onclick="event.stopPropagation()">
                      📋 View on CT.gov
                    </a>
                  `:""}
                </div>
              </div>
            `}).join("")}
          </div>
        `),`
        <div class="scri-agent-message ${a}" data-message-id="${e.id}">
          <div class="scri-agent-message-content">
            ${x(e.content)}
          </div>
          ${s}
        </div>
      `}).join(""),t.querySelectorAll(".scri-agent-trial-card").forEach(e=>{e.addEventListener("click",a=>{if(a.target.tagName==="A")return;const s=e.getAttribute("data-scri-url");s&&window.open(s,"_blank")})}))}function x(t){return r(t).replace(/^### (.+)$/gm,"<h4>$1</h4>").replace(/^## (.+)$/gm,"<h3>$1</h3>").replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/\*(.+?)\*/g,"<em>$1</em>").replace(/\[(NCT\d+)\]\([^)]+\)/g,'<a href="https://clinicaltrials.gov/study/$1" target="_blank">$1</a>').replace(/\[([^\]]+)\]\(([^)]+)\)/g,'<a href="$2" target="_blank">$1</a>').replace(/\n/g,"<br>").replace(/^• /gm,'<span class="bullet">•</span> ').replace(/^- /gm,'<span class="bullet">•</span> ')}function r(t){const e=document.createElement("div");return e.textContent=t,e.innerHTML}function M(){const t=document.getElementById("scri-agent-messages");t&&(t.scrollTop=t.scrollHeight)}function B(t){const e=document.getElementById("scri-agent-messages"),a=e==null?void 0:e.querySelector(`[data-message-id="${t}"]`);if(e&&a){const s=a.offsetTop-5;e.scrollTo({top:s,behavior:"smooth"})}}function l(){return`${Date.now()}-${Math.random().toString(36).slice(2,9)}`}chrome.runtime.onMessage.addListener((t,e,a)=>{if(t.type==="LOG_MESSAGE"){const{level:s,message:n}=t.payload,i="[SCRI Agent]";s==="error"?console.error(i,n):s==="warn"?console.warn(i,n):console.log(i,n)}return!1});document.readyState==="loading"?document.addEventListener("DOMContentLoaded",h):h();
