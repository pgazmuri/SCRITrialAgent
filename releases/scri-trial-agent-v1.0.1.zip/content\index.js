let m=[],d=!1,g=null;function f(){if(console.log("SCRI Trial Agent content script loaded"),document.querySelector(".search-container")){w();return}C()}function C(){let e=!1;const t=new MutationObserver((s,a)=>{if(e)return;document.querySelector(".search-container")&&(console.log("SCRI Agent: Found .search-container, injecting interface"),e=!0,a.disconnect(),w())});t.observe(document.body,{childList:!0,subtree:!0}),setTimeout(()=>{e||(console.warn("SCRI Agent: .search-container not found after 30s, giving up"),t.disconnect())},3e4)}function w(){const e=document.querySelector(".search-container");if(!e){console.warn("SCRI Agent: Could not find .search-container");return}for(g=document.createElement("div");e.firstChild;)g.appendChild(e.firstChild);I(e)}function I(e){e.innerHTML=`
    <div id="scri-agent-wrapper">
      <div class="scri-agent-tabs-container">
        <!-- Tab Navigation -->
        <div class="scri-agent-tab-nav">
          <button class="scri-agent-tab-btn active" data-tab="chat">
            <span class="scri-agent-tab-icon">💬</span>
            <span>AI Navigator</span>
          </button>
          <button class="scri-agent-tab-btn" data-tab="search">
            <span class="scri-agent-tab-icon">🔍</span>
            <span>Search Trials</span>
          </button>
        </div>

        <!-- Tab Content -->
        <div class="scri-agent-tab-content">
          <!-- Chat Tab -->
          <div id="scri-agent-chat-tab" class="scri-agent-tab-panel active">
            <div class="scri-agent-chat-container" id="scri-agent-chat-container">
              <!-- Welcome State (centered) -->
              <div class="scri-agent-welcome" id="scri-agent-welcome">
                <div class="scri-agent-welcome-icon">🔬</div>
                <h1 class="scri-agent-welcome-title">Find Your Clinical Trial</h1>
                <p class="scri-agent-welcome-subtitle">I'll help you discover SCRI trials that match your needs</p>
                
                <div class="scri-agent-welcome-input-area">
                  <textarea 
                    id="scri-agent-input" 
                    class="scri-agent-input" 
                    placeholder="Tell me about your cancer type and location..."
                    rows="1"
                  ></textarea>
                  <button id="scri-agent-send" class="scri-agent-send-btn" aria-label="Send message">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" style="width: 20px !important; height: 20px !important; min-width: 20px; min-height: 20px;">
                      <line x1="22" y1="2" x2="11" y2="13"></line>
                      <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                    </svg>
                  </button>
                </div>
                
                <div class="scri-agent-suggestions">
                  <button class="scri-agent-suggestion" data-query="I have breast cancer and live in Nashville, TN (37203)">
                    🎀 Breast cancer near Nashville
                  </button>
                  <button class="scri-agent-suggestion" data-query="I have lung cancer and live in Denver, CO (80202)">
                    🫁 Lung cancer near Denver
                  </button>
                  <button class="scri-agent-suggestion" data-query="What types of cancer do you have trials for?">
                    📋 See all cancer types
                  </button>
                </div>
              </div>
              
              <!-- Chat State (after first message) -->
              <div class="scri-agent-chat-active" id="scri-agent-chat-active" style="display: none;">
                <div id="scri-agent-messages" class="scri-agent-messages">
                  <!-- Messages will be inserted here -->
                </div>
                
                <div class="scri-agent-input-area-bottom">
                  <textarea 
                    id="scri-agent-input-active" 
                    class="scri-agent-input" 
                    placeholder="Ask a follow-up question..."
                    rows="1"
                  ></textarea>
                  <button id="scri-agent-send-active" class="scri-agent-send-btn" aria-label="Send message">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" style="width: 20px !important; height: 20px !important; min-width: 20px; min-height: 20px;">
                      <line x1="22" y1="2" x2="11" y2="13"></line>
                      <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- Search Tab (Original Content) -->
          <div id="scri-agent-search-tab" class="scri-agent-tab-panel">
            <div id="scri-agent-original-content"></div>
          </div>
        </div>
      </div>
    </div>
  `;const t=document.getElementById("scri-agent-original-content");if(t&&g)for(;g.firstChild;)t.appendChild(g.firstChild);S()}function S(){document.querySelectorAll(".scri-agent-tab-btn").forEach(n=>{n.addEventListener("click",()=>{const i=n.getAttribute("data-tab");i&&L(i)})});const e=document.getElementById("scri-agent-send"),t=document.getElementById("scri-agent-input");e==null||e.addEventListener("click",()=>v()),t==null||t.addEventListener("keydown",n=>{n.key==="Enter"&&!n.shiftKey&&(n.preventDefault(),v())});const s=document.getElementById("scri-agent-send-active"),a=document.getElementById("scri-agent-input-active");s==null||s.addEventListener("click",()=>y()),a==null||a.addEventListener("keydown",n=>{n.key==="Enter"&&!n.shiftKey&&(n.preventDefault(),y())}),document.querySelectorAll(".scri-agent-suggestion").forEach(n=>{n.addEventListener("click",()=>{const i=n.getAttribute("data-query");if(i){const r=document.getElementById("scri-agent-input");r&&(r.value=i,v())}})}),[t,a].forEach(n=>{n==null||n.addEventListener("input",()=>{n.style.height="auto",n.style.height=Math.min(n.scrollHeight,150)+"px"})})}function L(e){if(document.querySelectorAll(".scri-agent-tab-btn").forEach(t=>{t.classList.toggle("active",t.getAttribute("data-tab")===e)}),document.querySelectorAll(".scri-agent-tab-panel").forEach(t=>{t.classList.toggle("active",t.id===`scri-agent-${e}-tab`)}),e==="chat"){document.getElementById("scri-agent-welcome");const t=document.getElementById("scri-agent-chat-active");if((t==null?void 0:t.style.display)!=="none"){const s=document.getElementById("scri-agent-input-active");s==null||s.focus()}else{const s=document.getElementById("scri-agent-input");s==null||s.focus()}}}function k(){const e=document.getElementById("scri-agent-welcome"),t=document.getElementById("scri-agent-chat-active");if(e&&t){e.style.display="none",t.style.display="flex";const s=document.getElementById("scri-agent-input-active");s==null||s.focus()}}async function v(){const e=document.getElementById("scri-agent-input"),t=e.value.trim();!t||d||(e.value="",k(),await E(t))}async function y(){const e=document.getElementById("scri-agent-input-active"),t=e.value.trim();!t||d||(e.value="",e.style.height="auto",await E(t))}async function E(e){const t={id:l(),role:"user",content:e,timestamp:new Date};o(t);const s={id:l(),role:"assistant",content:"",timestamp:new Date,isLoading:!0};o(s),d=!0,h("Searching trials...");try{const a=await chrome.runtime.sendMessage({type:"CHAT",payload:{message:e}});if(b(s.id),d=!1,h(""),a!=null&&a.error){o({id:l(),role:"assistant",content:`❌ ${a.error}`,timestamp:new Date});return}const n={id:l(),role:"assistant",content:(a==null?void 0:a.text)||"Sorry, I encountered an error. Please try again.",timestamp:new Date,trials:a==null?void 0:a.trials};o(n)}catch(a){b(s.id),d=!1,h(""),o({id:l(),role:"assistant",content:`❌ Error: ${a instanceof Error?a.message:"Failed to connect. Please check your API key in the extension settings."}`,timestamp:new Date})}}function h(e){const t=document.getElementById("scri-agent-status");t&&(t.textContent=e)}function o(e){m.push(e),$(),e.role==="user"||e.isLoading?M():x(e.id)}function b(e){m=m.filter(t=>t.id!==e),$()}function $(){const e=document.getElementById("scri-agent-messages");e&&(e.innerHTML=m.map(t=>{if(t.isLoading)return`
          <div class="scri-agent-message scri-agent-message-assistant" data-message-id="${t.id}">
            <div class="scri-agent-message-content">
              <div class="scri-agent-loading">
                <span></span><span></span><span></span>
              </div>
            </div>
          </div>
        `;const s=t.role==="user"?"scri-agent-message-user":"scri-agent-message-assistant";let a="";return t.trials&&t.trials.length>0&&(a=`
          <div class="scri-agent-trials">
            ${t.trials.slice(0,5).map(n=>{var p;const i=n.scriUrl||(n.id?`https://trials.scri.com/trial/${n.id}`:"#");let r="";if(n.closestLocation)r=`
                  <div class="scri-agent-trial-location">
                    📍 ${c(n.closestLocation.city)}, ${c(n.closestLocation.state)}
                    ${n.closestLocation.distance?` (~${n.closestLocation.distance} mi)`:""}
                    ${n.locationCount>1?` • +${n.locationCount-1} more locations`:""}
                  </div>
                `;else if(n.closestCity){const u=n;r=`
                  <div class="scri-agent-trial-location">
                    📍 ${c(u.closestCity||"")}, ${c(u.closestState||"")}
                    ${u.distance?` (~${u.distance} mi)`:""}
                  </div>
                `}return`
              <div class="scri-agent-trial-card" data-scri-url="${i}">
                <div class="scri-agent-trial-header">
                  <strong>${c(n.name)}</strong>
                  <span class="scri-agent-trial-phase">${((p=n.phases)==null?void 0:p.join(", "))||""}</span>
                </div>
                <div class="scri-agent-trial-nct">${c(n.nctId)}</div>
                ${n.title?`<div class="scri-agent-trial-title">${c(n.title)}</div>`:""}
                ${r}
                <div class="scri-agent-trial-links">
                  <a href="${i}" target="_blank" class="scri-agent-trial-link scri-agent-trial-link-primary" onclick="event.stopPropagation()">
                    🏥 View on SCRI
                  </a>
                  ${n.nctId?`
                    <a href="https://clinicaltrials.gov/study/${n.nctId}" target="_blank" class="scri-agent-trial-link scri-agent-trial-link-secondary" onclick="event.stopPropagation()">
                      📋 View on CT.gov
                    </a>
                  `:""}
                </div>
              </div>
            `}).join("")}
          </div>
        `),`
        <div class="scri-agent-message ${s}" data-message-id="${t.id}">
          <div class="scri-agent-message-content">
            ${T(t.content)}
          </div>
          ${a}
        </div>
      `}).join(""),e.querySelectorAll(".scri-agent-trial-card").forEach(t=>{t.addEventListener("click",s=>{if(s.target.tagName==="A")return;const a=t.getAttribute("data-scri-url");a&&window.open(a,"_blank")})}))}function T(e){return c(e).replace(/^### (.+)$/gm,"<h4>$1</h4>").replace(/^## (.+)$/gm,"<h3>$1</h3>").replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/\*(.+?)\*/g,"<em>$1</em>").replace(/\[(NCT\d+)\]\([^)]+\)/g,'<a href="https://clinicaltrials.gov/study/$1" target="_blank">$1</a>').replace(/\[([^\]]+)\]\(([^)]+)\)/g,'<a href="$2" target="_blank">$1</a>').replace(/\n/g,"<br>").replace(/^• /gm,'<span class="bullet">•</span> ').replace(/^- /gm,'<span class="bullet">•</span> ')}function c(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}function M(){const e=document.getElementById("scri-agent-messages");e&&(e.scrollTop=e.scrollHeight)}function x(e){const t=document.getElementById("scri-agent-messages"),s=t==null?void 0:t.querySelector(`[data-message-id="${e}"]`);if(t&&s){const a=s.offsetTop-5;t.scrollTo({top:a,behavior:"smooth"})}}function l(){return`${Date.now()}-${Math.random().toString(36).slice(2,9)}`}chrome.runtime.onMessage.addListener((e,t,s)=>{if(e.type==="LOG_MESSAGE"){const{level:a,message:n}=e.payload,i="[SCRI Agent]";a==="error"?console.error(i,n):a==="warn"?console.warn(i,n):console.log(i,n)}return!1});document.readyState==="loading"?document.addEventListener("DOMContentLoaded",f):f();
