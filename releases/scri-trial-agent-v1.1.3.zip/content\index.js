let v=[],m=!1,y=null,l=[];const p=new Map;function k(){if(console.log("SCRI Trial Agent content script loaded"),document.querySelector(".search-container")){$();return}M()}function M(){let t=!1;const i=new MutationObserver((a,n)=>{if(t)return;document.querySelector(".search-container")&&(console.log("SCRI Agent: Found .search-container, injecting interface"),t=!0,n.disconnect(),$())});i.observe(document.body,{childList:!0,subtree:!0}),setTimeout(()=>{t||(console.warn("SCRI Agent: .search-container not found after 30s, giving up"),i.disconnect())},3e4)}function $(){chrome.runtime.sendMessage({type:"RESET_CONVERSATION"}).catch(()=>{});const t=document.querySelector(".search-container");if(!t){console.warn("SCRI Agent: Could not find .search-container");return}for(y=document.createElement("div");t.firstChild;)y.appendChild(t.firstChild);R(t)}function R(t){t.innerHTML=`
    <div id="scri-agent-wrapper">
      <div class="scri-agent-tabs-container">
        <!-- Tab Navigation -->
        <div class="scri-agent-tab-nav">
          <button class="scri-agent-tab-btn active" data-tab="chat">
            <span class="scri-agent-tab-icon">💬</span>
            <span>AI Navigator</span>
          </button>
          <button class="scri-agent-tab-btn" data-tab="search">
            <span class="scri-agent-tab-icon">🔍</span>
            <span>Search Trials</span>
          </button>
        </div>

        <!-- Tab Content - Now Two Column Layout -->
        <div class="scri-agent-tab-content">
          <!-- Chat Tab -->
          <div id="scri-agent-chat-tab" class="scri-agent-tab-panel active">
            <div class="scri-agent-two-column">
              <!-- Left Column: Chat Interface -->
              <div class="scri-agent-chat-column">
                <div class="scri-agent-chat-container" id="scri-agent-chat-container">
                  <!-- Welcome State (centered) -->
                  <div class="scri-agent-welcome" id="scri-agent-welcome">
                    <div class="scri-agent-welcome-icon">🔬</div>
                    <h1 class="scri-agent-welcome-title">Find Your Clinical Trial</h1>
                    <p class="scri-agent-welcome-subtitle">I'll help you discover SCRI trials that match your needs</p>
                    
                    <div class="scri-agent-welcome-input-area">
                      <textarea 
                        id="scri-agent-input" 
                        class="scri-agent-input" 
                        placeholder="Tell me about your cancer type and location..."
                        rows="1"
                      ></textarea>
                      <button id="scri-agent-send" class="scri-agent-send-btn" aria-label="Send message">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" style="width: 20px !important; height: 20px !important; min-width: 20px; min-height: 20px;">
                          <line x1="22" y1="2" x2="11" y2="13"></line>
                          <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                        </svg>
                      </button>
                    </div>
                    
                    <div class="scri-agent-suggestions">
                      <button class="scri-agent-suggestion" data-query="I have breast cancer and live in Nashville, TN (37203)">
                        🎀 Breast cancer near Nashville
                      </button>
                      <button class="scri-agent-suggestion" data-query="I have lung cancer and live in Denver, CO (80202)">
                        🫁 Lung cancer near Denver
                      </button>
                      <button class="scri-agent-suggestion" data-query="What types of cancer do you have trials for?">
                        📋 See all cancer types
                      </button>
                    </div>
                  </div>
                  
                  <!-- Chat State (after first message) -->
                  <div class="scri-agent-chat-active" id="scri-agent-chat-active" style="display: none;">
                    <div id="scri-agent-messages" class="scri-agent-messages">
                      <!-- Messages will be inserted here -->
                    </div>
                    
                    <div class="scri-agent-input-area-bottom">
                      <textarea 
                        id="scri-agent-input-active" 
                        class="scri-agent-input" 
                        placeholder="Ask a follow-up question..."
                        rows="1"
                      ></textarea>
                      <button id="scri-agent-send-active" class="scri-agent-send-btn" aria-label="Send message">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" style="width: 20px !important; height: 20px !important; min-width: 20px; min-height: 20px;">
                          <line x1="22" y1="2" x2="11" y2="13"></line>
                          <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              <!-- Right Column: My Trials Panel -->
              <div class="scri-agent-trials-column" id="scri-agent-trials-panel">
                <div class="scri-agent-trials-header">
                  <h2 class="scri-agent-trials-title">
                    <span>📋</span> My Trials
                    <span class="scri-agent-trials-count" id="scri-agent-trials-count">0</span>
                  </h2>
                  <button class="scri-agent-trials-clear" id="scri-agent-clear-list" title="Clear all trials">
                    🗑️
                  </button>
                </div>
                
                <div class="scri-agent-trials-list" id="scri-agent-trials-list">
                  <!-- Empty state -->
                  <div class="scri-agent-trials-empty" id="scri-agent-trials-empty">
                    <div class="scri-agent-trials-empty-icon">📝</div>
                    <p>No trials added yet</p>
                    <p class="scri-agent-trials-empty-hint">Search for trials and click "Add to My List" to start building your list</p>
                  </div>
                </div>
                
                <div class="scri-agent-trials-actions" id="scri-agent-trials-actions" style="display: none;">
                  <div class="scri-agent-eligibility-summary" id="scri-agent-eligibility-summary">
                    <!-- Eligibility summary will be rendered here -->
                  </div>
                  <button class="scri-agent-request-matching-btn" id="scri-agent-request-matching">
                    ✉️ Request Matching for Selected Trials
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- Search Tab (Original Content) -->
          <div id="scri-agent-search-tab" class="scri-agent-tab-panel">
            <div id="scri-agent-original-content"></div>
          </div>
        </div>
      </div>
    </div>
  `;const i=document.getElementById("scri-agent-original-content");if(i&&y)for(;y.firstChild;)i.appendChild(y.firstChild);_(),x()}async function x(){try{const t=await chrome.runtime.sendMessage({type:"GET_API_KEY",payload:{}});t!=null&&t.hasKey||w()}catch(t){console.error("Failed to check API key status:",t),w()}}function w(){const t=document.getElementById("scri-agent-welcome");if(!t)return;t.innerHTML=`
    <div class="scri-agent-welcome-icon">🔑</div>
    <h1 class="scri-agent-welcome-title">One-Time Setup</h1>
    <p class="scri-agent-welcome-subtitle">Enter your OpenAI API key to enable the AI Trial Navigator</p>
    
    <div class="scri-agent-api-key-form">
      <div class="scri-agent-api-key-input-wrapper">
        <input 
          type="password" 
          id="scri-agent-api-key-input" 
          class="scri-agent-api-key-input"
          placeholder="sk-proj-..."
          autocomplete="off"
        />
        <button id="scri-agent-toggle-key" class="scri-agent-toggle-key" type="button" aria-label="Show/hide key">
          👁️
        </button>
      </div>
      <button id="scri-agent-save-key" class="scri-agent-save-key-btn">
        Save & Start Chatting
      </button>
      <p id="scri-agent-key-error" class="scri-agent-key-error" style="display: none;"></p>
    </div>
    
    <p class="scri-agent-key-help">
      Don't have an API key? <a href="https://platform.openai.com/api-keys" target="_blank">Get one here</a> (requires OpenAI account)
    </p>
    <p class="scri-agent-key-privacy">
      🔒 Your key is stored locally in your browser and never sent anywhere except OpenAI.
    </p>
  `;const i=document.getElementById("scri-agent-api-key-input"),a=document.getElementById("scri-agent-save-key"),n=document.getElementById("scri-agent-toggle-key"),e=document.getElementById("scri-agent-key-error");n==null||n.addEventListener("click",()=>{i.type==="password"?(i.type="text",n.textContent="🙈"):(i.type="password",n.textContent="👁️")});const r=async()=>{const s=i.value.trim();if(!s){e&&(e.textContent="Please enter your API key",e.style.display="block");return}if(!s.startsWith("sk-")){e&&(e.textContent='Invalid API key format. Keys should start with "sk-"',e.style.display="block");return}a&&(a.textContent="Saving...",a.disabled=!0);try{await chrome.runtime.sendMessage({type:"SET_API_KEY",payload:{key:s}}),window.location.reload()}catch{e&&(e.textContent="Failed to save key. Please try again.",e.style.display="block"),a&&(a.textContent="Save & Start Chatting",a.disabled=!1)}};a==null||a.addEventListener("click",r),i==null||i.addEventListener("keydown",s=>{s.key==="Enter"&&(s.preventDefault(),r())}),i==null||i.focus()}function _(){document.querySelectorAll(".scri-agent-tab-btn").forEach(s=>{s.addEventListener("click",()=>{const c=s.getAttribute("data-tab");c&&q(c)})});const t=document.getElementById("scri-agent-send"),i=document.getElementById("scri-agent-input");t==null||t.addEventListener("click",()=>f()),i==null||i.addEventListener("keydown",s=>{s.key==="Enter"&&!s.shiftKey&&(s.preventDefault(),f())});const a=document.getElementById("scri-agent-send-active"),n=document.getElementById("scri-agent-input-active");a==null||a.addEventListener("click",()=>I()),n==null||n.addEventListener("keydown",s=>{s.key==="Enter"&&!s.shiftKey&&(s.preventDefault(),I())}),document.querySelectorAll(".scri-agent-suggestion").forEach(s=>{s.addEventListener("click",()=>{const c=s.getAttribute("data-query");if(c){const d=document.getElementById("scri-agent-input");d&&(d.value=c,f())}})}),[i,n].forEach(s=>{s==null||s.addEventListener("input",()=>{s.style.height="auto",s.style.height=Math.min(s.scrollHeight,150)+"px"})});const e=document.getElementById("scri-agent-clear-list");e==null||e.addEventListener("click",()=>{l.length!==0&&confirm("Are you sure you want to clear all trials from your list?")&&H()});const r=document.getElementById("scri-agent-request-matching");r==null||r.addEventListener("click",()=>{U()})}function q(t){if(document.querySelectorAll(".scri-agent-tab-btn").forEach(i=>{i.classList.toggle("active",i.getAttribute("data-tab")===t)}),document.querySelectorAll(".scri-agent-tab-panel").forEach(i=>{i.classList.toggle("active",i.id===`scri-agent-${t}-tab`)}),t==="chat"){document.getElementById("scri-agent-welcome");const i=document.getElementById("scri-agent-chat-active");if((i==null?void 0:i.style.display)!=="none"){const a=document.getElementById("scri-agent-input-active");a==null||a.focus()}else{const a=document.getElementById("scri-agent-input");a==null||a.focus()}}}function B(){const t=document.getElementById("scri-agent-welcome"),i=document.getElementById("scri-agent-chat-active");if(t&&i){t.style.display="none",i.style.display="flex";const a=document.getElementById("scri-agent-input-active");a==null||a.focus()}}async function f(){const t=document.getElementById("scri-agent-input"),i=t.value.trim();!i||m||(t.value="",B(),await S(i))}async function I(){const t=document.getElementById("scri-agent-input-active"),i=t.value.trim();!i||m||(t.value="",t.style.height="auto",await S(i))}async function S(t){const i={id:g(),role:"user",content:t,timestamp:new Date};u(i);const a={id:g(),role:"assistant",content:"",timestamp:new Date,isLoading:!0};u(a),m=!0,b("Searching trials...");try{const n=l.map(s=>({id:s.trial.id,name:s.trial.name,title:s.trial.title,nctId:s.trial.nctId,status:s.status,statusReason:s.statusReason})),e=await chrome.runtime.sendMessage({type:"CHAT",payload:{message:t,currentTrialList:n}});if(E(a.id),m=!1,b(""),e!=null&&e.error){u({id:g(),role:"assistant",content:`❌ ${e.error}`,timestamp:new Date});return}const r={id:g(),role:"assistant",content:(e==null?void 0:e.text)||"Sorry, I encountered an error. Please try again.",timestamp:new Date,trials:e==null?void 0:e.trials};if(u(r),e!=null&&e.eligibilityUpdates&&e.eligibilityUpdates.length>0)for(const s of e.eligibilityUpdates)C(s.trialId,s.status,s.reason);if(e!=null&&e.trialsToAdd&&e.trialsToAdd.length>0){console.log("[SCRI Agent] Agent adding trials to list:",e.trialsToAdd.length);for(const s of e.trialsToAdd){const c=s.trialData;c&&c.id&&(T(c),s.reason&&C(c.id,"unknown",s.reason))}}if(e!=null&&e.trialsToRemove&&e.trialsToRemove.length>0){console.log("[SCRI Agent] Agent removing trials from list:",e.trialsToRemove.length);for(const s of e.trialsToRemove)L(s.trialId)}}catch(n){E(a.id),m=!1,b(""),u({id:g(),role:"assistant",content:`❌ Error: ${n instanceof Error?n.message:"Failed to connect. Please check your API key in the extension settings."}`,timestamp:new Date})}}function b(t){const i=document.getElementById("scri-agent-status");i&&(i.textContent=t)}function u(t){v.push(t),A(),t.role==="user"||t.isLoading?N():P(t.id)}function E(t){v=v.filter(i=>i.id!==t),A()}function A(){const t=document.getElementById("scri-agent-messages");t&&(t.innerHTML=v.map(i=>{if(i.isLoading)return`
          <div class="scri-agent-message scri-agent-message-assistant" data-message-id="${i.id}">
            <div class="scri-agent-message-content">
              <div class="scri-agent-loading">
                <span></span><span></span><span></span>
              </div>
            </div>
          </div>
        `;const a=i.role==="user"?"scri-agent-message-user":"scri-agent-message-assistant";let n="";return i.trials&&i.trials.length>0&&(i.trials.slice(0,5).forEach(e=>{e.id&&p.set(e.id,e)}),n=`
          <div class="scri-agent-trials">
            ${i.trials.slice(0,5).map(e=>{var c;const r=e.scriUrl||(e.id?`https://trials.scri.com/trialdetail/${e.id}`:"#");let s="";if(e.closestLocation)s=`
                  <div class="scri-agent-trial-location">
                    📍 ${o(e.closestLocation.city)}, ${o(e.closestLocation.state)}
                    ${e.closestLocation.distance?` (~${e.closestLocation.distance} mi)`:""}
                    ${e.locationCount>1?` • +${e.locationCount-1} more locations`:""}
                  </div>
                `;else if(e.closestCity){const d=e;s=`
                  <div class="scri-agent-trial-location">
                    📍 ${o(d.closestCity||"")}, ${o(d.closestState||"")}
                    ${d.distance?` (~${d.distance} mi)`:""}
                  </div>
                `}return`
              <div class="scri-agent-trial-card" data-scri-url="${r}" data-trial-id="${e.id}">
                <div class="scri-agent-trial-header">
                  <strong>${o(e.name)}</strong>
                  <span class="scri-agent-trial-phase">${((c=e.phases)==null?void 0:c.join(", "))||""}</span>
                </div>
                <div class="scri-agent-trial-nct">${o(e.nctId)}</div>
                ${e.title?`<div class="scri-agent-trial-title">${o(e.title)}</div>`:""}
                ${s}
                <div class="scri-agent-trial-links">
                  <button class="scri-agent-add-to-list-btn" data-trial-id="${e.id}">
                    ➕ Add to My List
                  </button>
                  <a href="${r}" target="_blank" class="scri-agent-trial-link scri-agent-trial-link-primary">
                    🏥 SCRI
                  </a>
                  ${e.nctId?`
                    <a href="https://clinicaltrials.gov/study/${e.nctId}" target="_blank" class="scri-agent-trial-link scri-agent-trial-link-secondary">
                      📋 CT.gov
                    </a>
                  `:""}
                </div>
              </div>
            `}).join("")}
          </div>
        `),`
        <div class="scri-agent-message ${a}" data-message-id="${i.id}">
          <div class="scri-agent-message-content">
            ${D(i.content)}
          </div>
          ${n}
        </div>
      `}).join(""),t.querySelectorAll(".scri-agent-trial-card").forEach(i=>{i.addEventListener("click",a=>{const n=a.target;if(n.tagName==="A"||n.tagName==="BUTTON")return;const e=i.getAttribute("data-scri-url");e&&window.open(e,"_blank")})}),t.querySelectorAll(".scri-agent-add-to-list-btn").forEach(i=>{i.addEventListener("click",a=>{a.stopPropagation(),a.preventDefault();const n=i.getAttribute("data-trial-id");if(console.log("[SCRI Agent] Add to list button clicked, trialId:",n),console.log("[SCRI Agent] Cache size:",p.size,"Cache keys:",Array.from(p.keys())),n){const e=p.get(n);console.log("[SCRI Agent] Trial from cache:",e),e?(T(e),i.textContent="✓ Added",i.classList.add("scri-agent-add-to-list-btn-added"),i.disabled=!0):console.error("[SCRI Agent] Trial not found in cache:",n)}})}))}function D(t){return o(t).replace(/^### (.+)$/gm,"<h4>$1</h4>").replace(/^## (.+)$/gm,"<h3>$1</h3>").replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/\*(.+?)\*/g,"<em>$1</em>").replace(/\[(NCT\d+)\]\([^)]+\)/g,'<a href="https://clinicaltrials.gov/study/$1" target="_blank">$1</a>').replace(/\[([^\]]+)\]\(([^)]+)\)/g,'<a href="$2" target="_blank">$1</a>').replace(/\n/g,"<br>").replace(/^• /gm,'<span class="bullet">•</span> ').replace(/^- /gm,'<span class="bullet">•</span> ')}function o(t){if(!t)return"";const i=document.createElement("div");return i.textContent=t,i.innerHTML}function N(){const t=document.getElementById("scri-agent-messages");t&&(t.scrollTop=t.scrollHeight)}function P(t){const i=document.getElementById("scri-agent-messages"),a=i==null?void 0:i.querySelector(`[data-message-id="${t}"]`);if(i&&a){const n=a.offsetTop-5;i.scrollTo({top:n,behavior:"smooth"})}}function T(t){if(l.some(a=>a.trial.id===t.id)){console.log("[SCRI Agent] Trial already in list:",t.name);return}const i={trial:t,addedAt:new Date,status:"unknown"};l.push(i),h(),console.log("[SCRI Agent] Added trial to list:",t.name,"Total:",l.length)}function L(t){l=l.filter(i=>i.trial.id!==t),h()}function C(t,i,a){const n=l.find(e=>e.trial.id===t);n&&(n.status=i,n.statusReason=a,h())}function H(){l=[],h()}function O(t){switch(t){case"likely_eligible":return'<span class="scri-agent-status-badge scri-agent-status-eligible" title="Likely Eligible">✅</span>';case"likely_ineligible":return'<span class="scri-agent-status-badge scri-agent-status-ineligible" title="Likely Ineligible">❌</span>';case"needs_review":return'<span class="scri-agent-status-badge scri-agent-status-review" title="Needs Physician Review">⚠️</span>';default:return'<span class="scri-agent-status-badge scri-agent-status-unknown" title="Eligibility Unknown">❓</span>'}}function h(){const t=document.getElementById("scri-agent-trials-list"),i=document.getElementById("scri-agent-trials-count"),a=document.getElementById("scri-agent-trials-actions"),n=document.getElementById("scri-agent-eligibility-summary");if(!t)return;if(i&&(i.textContent=String(l.length)),l.length===0){a&&(a.style.display="none"),t.innerHTML=`
      <div class="scri-agent-trials-empty">
        <div class="scri-agent-trials-empty-icon">📝</div>
        <p>No trials added yet</p>
        <p class="scri-agent-trials-empty-hint">Search for trials and click "Add to My List" to start building your list</p>
      </div>
    `;return}a&&(a.style.display="block");const e={likely_eligible:l.filter(r=>r.status==="likely_eligible").length,likely_ineligible:l.filter(r=>r.status==="likely_ineligible").length,needs_review:l.filter(r=>r.status==="needs_review").length,unknown:l.filter(r=>r.status==="unknown").length};n&&(n.innerHTML=`
      <div class="scri-agent-eligibility-counts">
        ${e.likely_eligible>0?`<span class="scri-agent-status-count eligible">✅ ${e.likely_eligible} Likely Eligible</span>`:""}
        ${e.needs_review>0?`<span class="scri-agent-status-count review">⚠️ ${e.needs_review} Needs Review</span>`:""}
        ${e.unknown>0?`<span class="scri-agent-status-count unknown">❓ ${e.unknown} Unknown</span>`:""}
        ${e.likely_ineligible>0?`<span class="scri-agent-status-count ineligible">❌ ${e.likely_ineligible} Likely Ineligible</span>`:""}
      </div>
    `),t.innerHTML=l.map(r=>{const s=r.trial,c=s.scriUrl||`https://trials.scri.com/trialdetail/${s.id}`;let d="";return"closestLocation"in s&&s.closestLocation?d=`📍 ${o(s.closestLocation.city)}, ${o(s.closestLocation.state)}`:"closestCity"in s&&s.closestCity&&(d=`📍 ${o(s.closestCity)}, ${o(s.closestState||"")}`),`
      <div class="scri-agent-trial-item ${r.status==="likely_ineligible"?"scri-agent-trial-item-ineligible":""}" data-trial-id="${s.id}">
        <div class="scri-agent-trial-item-header">
          ${O(r.status)}
          <strong class="scri-agent-trial-item-name">${o(s.name)}</strong>
          <button class="scri-agent-trial-item-remove" data-remove-id="${s.id}" title="Remove from list">×</button>
        </div>
        <div class="scri-agent-trial-item-title">${o(s.title)}</div>
        ${d?`<div class="scri-agent-trial-item-location">${d}</div>`:""}
        ${r.statusReason?`<div class="scri-agent-trial-item-reason">${o(r.statusReason)}</div>`:""}
        <div class="scri-agent-trial-item-links">
          <a href="${c}" target="_blank" class="scri-agent-mini-link">View on SCRI</a>
          ${s.nctId?`<a href="https://clinicaltrials.gov/study/${s.nctId}" target="_blank" class="scri-agent-mini-link">CT.gov</a>`:""}
        </div>
      </div>
    `}).join(""),t.querySelectorAll(".scri-agent-trial-item-remove").forEach(r=>{r.addEventListener("click",s=>{s.stopPropagation();const c=r.getAttribute("data-remove-id");c&&L(c)})})}function U(){const t=l.filter(n=>n.status!=="likely_ineligible");if(t.length===0){alert("No eligible trials to request matching for. All trials in your list appear to be ineligible based on your profile.");return}const i=t.map(n=>`• ${n.trial.name}: ${n.trial.title}`).join(`
`);confirm(`📬 Request Matching

You are about to request matching for ${t.length} trial(s):

${i}

A clinical trial coordinator will review your request and contact you to discuss next steps.

Click OK to submit your request.`)&&(alert(`✅ Request Submitted!

Your matching request for ${t.length} trial(s) has been submitted.

A coordinator from Sarah Cannon Research Institute will contact you within 2-3 business days.

Reference ID: ${g()}`),console.log("[SCRI Agent] Matching request submitted for:",t.map(n=>n.trial.name)))}function g(){return`${Date.now()}-${Math.random().toString(36).slice(2,9)}`}chrome.runtime.onMessage.addListener((t,i,a)=>{if(t.type==="LOG_MESSAGE"){const{level:n,message:e}=t.payload,r="[SCRI Agent]";n==="error"?console.error(r,e):n==="warn"?console.warn(r,e):console.log(r,e)}return!1});document.readyState==="loading"?document.addEventListener("DOMContentLoaded",k):k();
