let g=[],l=!1,d=null;function h(){if(console.log("SCRI Trial Agent content script loaded"),document.querySelector(".search-container")){y();return}E()}function E(){let e=!1;const t=new MutationObserver((s,a)=>{if(e)return;document.querySelector(".search-container")&&(console.log("SCRI Agent: Found .search-container, injecting interface"),e=!0,a.disconnect(),y())});t.observe(document.body,{childList:!0,subtree:!0}),setTimeout(()=>{e||(console.warn("SCRI Agent: .search-container not found after 30s, giving up"),t.disconnect())},3e4)}function y(){const e=document.querySelector(".search-container");if(!e){console.warn("SCRI Agent: Could not find .search-container");return}for(d=document.createElement("div");e.firstChild;)d.appendChild(e.firstChild);C(e)}function C(e){e.innerHTML=`
    <div id="scri-agent-wrapper">
      <div class="scri-agent-tabs-container">
        <!-- Tab Navigation -->
        <div class="scri-agent-tab-nav">
          <button class="scri-agent-tab-btn active" data-tab="chat">
            <span class="scri-agent-tab-icon">💬</span>
            <span>AI Navigator</span>
          </button>
          <button class="scri-agent-tab-btn" data-tab="search">
            <span class="scri-agent-tab-icon">🔍</span>
            <span>Search Trials</span>
          </button>
        </div>

        <!-- Tab Content -->
        <div class="scri-agent-tab-content">
          <!-- Chat Tab -->
          <div id="scri-agent-chat-tab" class="scri-agent-tab-panel active">
            <div class="scri-agent-chat-container" id="scri-agent-chat-container">
              <!-- Welcome State (centered) -->
              <div class="scri-agent-welcome" id="scri-agent-welcome">
                <div class="scri-agent-welcome-icon">🔬</div>
                <h1 class="scri-agent-welcome-title">Find Your Clinical Trial</h1>
                <p class="scri-agent-welcome-subtitle">I'll help you discover SCRI trials that match your needs</p>
                
                <div class="scri-agent-welcome-input-area">
                  <textarea 
                    id="scri-agent-input" 
                    class="scri-agent-input" 
                    placeholder="Tell me about your cancer type and location..."
                    rows="1"
                  ></textarea>
                  <button id="scri-agent-send" class="scri-agent-send-btn" aria-label="Send message">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" style="width: 20px !important; height: 20px !important; min-width: 20px; min-height: 20px;">
                      <line x1="22" y1="2" x2="11" y2="13"></line>
                      <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                    </svg>
                  </button>
                </div>
                
                <div class="scri-agent-suggestions">
                  <button class="scri-agent-suggestion" data-query="I have breast cancer and live in Nashville, TN (37203)">
                    🎀 Breast cancer near Nashville
                  </button>
                  <button class="scri-agent-suggestion" data-query="I have lung cancer and live in Denver, CO (80202)">
                    🫁 Lung cancer near Denver
                  </button>
                  <button class="scri-agent-suggestion" data-query="What types of cancer do you have trials for?">
                    📋 See all cancer types
                  </button>
                </div>
              </div>
              
              <!-- Chat State (after first message) -->
              <div class="scri-agent-chat-active" id="scri-agent-chat-active" style="display: none;">
                <div id="scri-agent-messages" class="scri-agent-messages">
                  <!-- Messages will be inserted here -->
                </div>
                
                <div class="scri-agent-input-area-bottom">
                  <textarea 
                    id="scri-agent-input-active" 
                    class="scri-agent-input" 
                    placeholder="Ask a follow-up question..."
                    rows="1"
                  ></textarea>
                  <button id="scri-agent-send-active" class="scri-agent-send-btn" aria-label="Send message">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" style="width: 20px !important; height: 20px !important; min-width: 20px; min-height: 20px;">
                      <line x1="22" y1="2" x2="11" y2="13"></line>
                      <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- Search Tab (Original Content) -->
          <div id="scri-agent-search-tab" class="scri-agent-tab-panel">
            <div id="scri-agent-original-content"></div>
          </div>
        </div>
      </div>
    </div>
  `;const t=document.getElementById("scri-agent-original-content");if(t&&d)for(;d.firstChild;)t.appendChild(d.firstChild);$()}function $(){document.querySelectorAll(".scri-agent-tab-btn").forEach(n=>{n.addEventListener("click",()=>{const i=n.getAttribute("data-tab");i&&I(i)})});const e=document.getElementById("scri-agent-send"),t=document.getElementById("scri-agent-input");e==null||e.addEventListener("click",()=>u()),t==null||t.addEventListener("keydown",n=>{n.key==="Enter"&&!n.shiftKey&&(n.preventDefault(),u())});const s=document.getElementById("scri-agent-send-active"),a=document.getElementById("scri-agent-input-active");s==null||s.addEventListener("click",()=>p()),a==null||a.addEventListener("keydown",n=>{n.key==="Enter"&&!n.shiftKey&&(n.preventDefault(),p())}),document.querySelectorAll(".scri-agent-suggestion").forEach(n=>{n.addEventListener("click",()=>{const i=n.getAttribute("data-query");if(i){const v=document.getElementById("scri-agent-input");v&&(v.value=i,u())}})}),[t,a].forEach(n=>{n==null||n.addEventListener("input",()=>{n.style.height="auto",n.style.height=Math.min(n.scrollHeight,150)+"px"})})}function I(e){if(document.querySelectorAll(".scri-agent-tab-btn").forEach(t=>{t.classList.toggle("active",t.getAttribute("data-tab")===e)}),document.querySelectorAll(".scri-agent-tab-panel").forEach(t=>{t.classList.toggle("active",t.id===`scri-agent-${e}-tab`)}),e==="chat"){document.getElementById("scri-agent-welcome");const t=document.getElementById("scri-agent-chat-active");if((t==null?void 0:t.style.display)!=="none"){const s=document.getElementById("scri-agent-input-active");s==null||s.focus()}else{const s=document.getElementById("scri-agent-input");s==null||s.focus()}}}function S(){const e=document.getElementById("scri-agent-welcome"),t=document.getElementById("scri-agent-chat-active");if(e&&t){e.style.display="none",t.style.display="flex";const s=document.getElementById("scri-agent-input-active");s==null||s.focus()}}async function u(){const e=document.getElementById("scri-agent-input"),t=e.value.trim();!t||l||(e.value="",S(),await b(t))}async function p(){const e=document.getElementById("scri-agent-input-active"),t=e.value.trim();!t||l||(e.value="",e.style.height="auto",await b(t))}async function b(e){const t={id:o(),role:"user",content:e,timestamp:new Date};r(t);const s={id:o(),role:"assistant",content:"",timestamp:new Date,isLoading:!0};r(s),l=!0,m("Searching trials...");try{const a=await chrome.runtime.sendMessage({type:"CHAT",payload:{message:e}});if(f(s.id),l=!1,m(""),a!=null&&a.error){r({id:o(),role:"assistant",content:`❌ ${a.error}`,timestamp:new Date});return}const n={id:o(),role:"assistant",content:(a==null?void 0:a.text)||"Sorry, I encountered an error. Please try again.",timestamp:new Date,trials:a==null?void 0:a.trials};r(n)}catch(a){f(s.id),l=!1,m(""),r({id:o(),role:"assistant",content:`❌ Error: ${a instanceof Error?a.message:"Failed to connect. Please check your API key in the extension settings."}`,timestamp:new Date})}}function m(e){const t=document.getElementById("scri-agent-status");t&&(t.textContent=e)}function r(e){g.push(e),w(),e.role==="user"||e.isLoading?k():T(e.id)}function f(e){g=g.filter(t=>t.id!==e),w()}function w(){const e=document.getElementById("scri-agent-messages");e&&(e.innerHTML=g.map(t=>{if(t.isLoading)return`
          <div class="scri-agent-message scri-agent-message-assistant" data-message-id="${t.id}">
            <div class="scri-agent-message-content">
              <div class="scri-agent-loading">
                <span></span><span></span><span></span>
              </div>
            </div>
          </div>
        `;const s=t.role==="user"?"scri-agent-message-user":"scri-agent-message-assistant";let a="";return t.trials&&t.trials.length>0&&(a=`
          <div class="scri-agent-trials">
            ${t.trials.slice(0,5).map(n=>{var i;return`
              <div class="scri-agent-trial-card" data-scri-url="${n.scriUrl||""}" data-ctgov-url="${n.ctGovUrl||""}">
                <div class="scri-agent-trial-header">
                  <strong>${c(n.name)}</strong>
                  <span class="scri-agent-trial-phase">${((i=n.phases)==null?void 0:i.join(", "))||""}</span>
                </div>
                <div class="scri-agent-trial-nct">${c(n.nctId)}</div>
                <div class="scri-agent-trial-title">${c(n.title)}</div>
                ${n.closestLocation?`
                  <div class="scri-agent-trial-location">
                    📍 ${c(n.closestLocation.city)}, ${c(n.closestLocation.state)}
                    ${n.closestLocation.distance?` (~${n.closestLocation.distance} mi)`:""}
                    ${n.locationCount>1?` • +${n.locationCount-1} more locations`:""}
                  </div>
                `:""}
                <div class="scri-agent-trial-links">
                  <a href="${n.scriUrl||"#"}" target="_blank" class="scri-agent-trial-link scri-agent-trial-link-primary" onclick="event.stopPropagation()">
                    View on SCRI
                  </a>
                  ${n.ctGovUrl?`
                    <a href="${n.ctGovUrl}" target="_blank" class="scri-agent-trial-link scri-agent-trial-link-secondary" onclick="event.stopPropagation()">
                      ClinicalTrials.gov
                    </a>
                  `:""}
                </div>
              </div>
            `}).join("")}
          </div>
        `),`
        <div class="scri-agent-message ${s}" data-message-id="${t.id}">
          <div class="scri-agent-message-content">
            ${L(t.content)}
          </div>
          ${a}
        </div>
      `}).join(""),e.querySelectorAll(".scri-agent-trial-card").forEach(t=>{t.addEventListener("click",s=>{if(s.target.tagName==="A")return;const a=t.getAttribute("data-scri-url");a&&window.open(a,"_blank")})}))}function L(e){return c(e).replace(/^### (.+)$/gm,"<h4>$1</h4>").replace(/^## (.+)$/gm,"<h3>$1</h3>").replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/\*(.+?)\*/g,"<em>$1</em>").replace(/\[(NCT\d+)\]\([^)]+\)/g,'<a href="https://clinicaltrials.gov/study/$1" target="_blank">$1</a>').replace(/\[([^\]]+)\]\(([^)]+)\)/g,'<a href="$2" target="_blank">$1</a>').replace(/\n/g,"<br>").replace(/^• /gm,'<span class="bullet">•</span> ').replace(/^- /gm,'<span class="bullet">•</span> ')}function c(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}function k(){const e=document.getElementById("scri-agent-messages");e&&(e.scrollTop=e.scrollHeight)}function T(e){const t=document.getElementById("scri-agent-messages"),s=t==null?void 0:t.querySelector(`[data-message-id="${e}"]`);if(t&&s){const a=s.offsetTop-5;t.scrollTo({top:a,behavior:"smooth"})}}function o(){return`${Date.now()}-${Math.random().toString(36).slice(2,9)}`}chrome.runtime.onMessage.addListener((e,t,s)=>{if(e.type==="LOG_MESSAGE"){const{level:a,message:n}=e.payload,i="[SCRI Agent]";a==="error"?console.error(i,n):a==="warn"?console.warn(i,n):console.log(i,n)}return!1});document.readyState==="loading"?document.addEventListener("DOMContentLoaded",h):h();
